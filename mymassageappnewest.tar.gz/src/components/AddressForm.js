import React, { useState } from 'react';
import api from '../services/api';
import { MapPin } from 'lucide-react';

const statesList = [
  'AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA',
  'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD',
  'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ',
  'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC',
  'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY'
];

const AddressForm = ({ onAddressConfirmed }) => {
  const [address, setAddress] = useState({
    street_number: '',
    street_name: '',
    unit: '',
    city: '',
    state: '',
    zip: ''
  });

  const [errors, setErrors] = useState({});
  const [isConfirmed, setIsConfirmed] = useState(false);

  const geocodeAddress = async (address) => {
    try {
      // Log the request being made
      console.log('Making geocoding request for address:', address);

      const response = await api.get('/api/geocode', {
        params: { address }
      });

      // Log the complete response for debugging
      console.log('Geocoding response:', response.data);

      // Destructure and validate the response data
      const { lat, lng } = response.data;
      
      // Strict validation of latitude and longitude
      if (typeof lat !== 'number' || typeof lng !== 'number' ||
          lat < -90 || lat > 90 || lng < -180 || lng > 180) {
        console.error('Invalid coordinates received:', { lat, lng });
        throw new Error('INVALID_COORDINATES');
      }

      console.log('Valid coordinates received:', { lat, lng });
      return { lat, lng };

    } catch (error) {
      // Log the complete error object for debugging
      console.error('Geocoding error details:', {
        message: error.message,
        response: error.response?.data,
        status: error.response?.status
      });

      if (error.response) {
        // Handle specific HTTP error responses
        const status = error.response.status;
        const message = error.response.data.message;

        if (status === 404) {
          throw new Error(message || 'Address not found. Please verify the address and try again.');
        } else if (status === 429) {
          throw new Error(message || 'Service is temporarily unavailable. Please try again in a few minutes.');
        } else if (status === 403) {
          throw new Error(message || 'Address verification service is currently unavailable.');
        } else {
          throw new Error(message || 'Error verifying address. Please try again.');
        }
      } else if (error.request) {
        console.error('Network error details:', error.request);
        throw new Error('Unable to reach the address verification service. Please check your internet connection.');
      } else if (error.message === 'INVALID_COORDINATES') {
        throw new Error('Received invalid coordinates from the server. Please try again.');
      } else {
        console.error('Unexpected error:', error);
        throw new Error(`Unable to verify address: ${error.message}`);
      }
    }
  };

  const validateField = (name, value) => {
    switch (name) {
      case 'street_number':
        return /^\d+$/.test(value.trim()) ? '' : 'Enter a valid street number';
      case 'street_name':
        return value.trim().length >= 2 ? '' : 'Enter a valid street name';
      case 'city':
        return value.trim().length >= 2 ? '' : 'Enter a valid city name';
      case 'state':
        return /^[A-Z]{2}$/.test(value.trim()) ? '' : 'Enter a valid 2-letter state code';
      case 'zip':
        return /^\d{5}$/.test(value) ? '' : 'Enter a valid 5-digit zip code';
      default:
        return '';
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    let formattedValue = value;
    if (name === 'state') {
      formattedValue = value.toUpperCase();
    }
    setAddress(prev => ({
      ...prev,
      [name]: formattedValue
    }));

    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
    if (isConfirmed) {
      setIsConfirmed(false);
    }
  };

  const handleConfirm = async () => {
    // Clear any existing errors
    setErrors({});
    const newErrors = {};

    // Validate fields except 'unit'
    Object.keys(address).forEach(key => {
      if (key !== 'unit') {
        const error = validateField(key, address[key]);
        if (error) newErrors[key] = error;
      }
    });

    // If validation errors exist, show them and return
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    // Construct the full address
    const fullAddress = `${address.street_number} ${address.street_name}${
      address.unit ? ` Unit ${address.unit}` : ''
    }, ${address.city}, ${address.state} ${address.zip}`;

    try {
      // Log the address being geocoded
      console.log('Attempting to geocode address:', fullAddress);
      
      // Attempt to geocode the address
      const { lat, lng } = await geocodeAddress(fullAddress);
      
      // Log successful geocoding
      console.log('Address successfully geocoded:', { lat, lng });
      
      // If we get here, geocoding was successful
      setIsConfirmed(true);
      onAddressConfirmed({
        fullAddress,
        lat,
        lng,
        ...address
      });
    } catch (error) {
      // Log the complete error for debugging
      console.error('Error in handleConfirm:', {
        error,
        message: error.message,
        response: error.response?.data
      });
      
      // Handle specific geocoding errors
      let errorMessage;
      
      if (error.message.includes('Address not found')) {
        errorMessage = 'We could not find this address. Please verify all fields and try again.';
      } else if (error.message.includes('Service is temporarily unavailable')) {
        errorMessage = 'Our address verification service is temporarily unavailable. Please try again in a few minutes.';
      } else if (error.message.includes('Unable to reach')) {
        errorMessage = 'Unable to verify address. Please check your internet connection and try again.';
      } else if (error.message.includes('Invalid coordinates')) {
        errorMessage = 'We received an invalid response while verifying your address. Please try again.';
      } else {
        // Use the error message from the server if available, otherwise use a generic message
        errorMessage = error.message || 'Failed to verify address. Please check all fields and try again.';
      }
      
      // Set the error message and scroll it into view
      setErrors(prev => ({
        ...prev,
        geocoding: errorMessage
      }));

      // Find the error message element and scroll it into view
      setTimeout(() => {
        const errorElement = document.querySelector('.bg-red-50');
        if (errorElement) {
          errorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 100);
    }
  };

  return (
<div className="space-y-6">
  <div className="bg-white rounded-lg shadow-sm p-4 border border-slate-200">
    <div className="flex items-center mb-3 border-b pb-2">
      <MapPin className="w-5 h-5 text-blue-500" />
      <h2 className="font-medium ml-2">Service Location</h2>
    </div>

    <div className="space-y-4">
      {/* Street Number */}
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">
          Street # <span className="text-xs text-slate-500">(e.g., 123)</span>
        </label>
        <input
          type="text"
          name="street_number"
          value={address.street_number}
          onChange={handleChange}
          className={`w-full p-2 border rounded-md ${
            errors.street_number ? 'border-red-500' : 'border-slate-200'
          }`}
          disabled={isConfirmed}
        />
        {errors.street_number && (
          <span className="text-xs text-red-500 mt-1">{errors.street_number}</span>
        )}
      </div>

      {/* Street Name */}
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">
          Street Name <span className="text-xs text-slate-500">(e.g., Maple Avenue)</span>
        </label>
        <input
          type="text"
          name="street_name"
          value={address.street_name}
          onChange={handleChange}
          className={`w-full p-2 border rounded-md ${
            errors.street_name ? 'border-red-500' : 'border-slate-200'
          }`}
          disabled={isConfirmed}
        />
        {errors.street_name && (
          <span className="text-xs text-red-500 mt-1">{errors.street_name}</span>
        )}
      </div>

      {/* Unit (Optional) */}
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">
          Unit/Apt <span className="text-xs text-slate-500">(Optional)</span>
        </label>
        <input
          type="text"
          name="unit"
          value={address.unit}
          onChange={handleChange}
          className="w-full p-2 border border-slate-200 rounded-md"
          disabled={isConfirmed}
        />
      </div>

      {/* City */}
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">
          City
        </label>
        <input
          type="text"
          name="city"
          value={address.city}
          onChange={handleChange}
          className={`w-full p-2 border rounded-md ${
            errors.city ? 'border-red-500' : 'border-slate-200'
          }`}
          disabled={isConfirmed}
        />
        {errors.city && (
          <span className="text-xs text-red-500 mt-1">{errors.city}</span>
        )}
      </div>

      {/* State - Now a dropdown */}
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">
          State
        </label>
        <select
          name="state"
          value={address.state}
          onChange={handleChange}
          className={`w-full p-2 border rounded-md ${
            errors.state ? 'border-red-500' : 'border-slate-200'
          }`}
          disabled={isConfirmed}
        >
          <option value="">Select State</option>
          {statesList.map(state => (
            <option key={state} value={state}>{state}</option>
          ))}
        </select>
        {errors.state && (
          <span className="text-xs text-red-500 mt-1">{errors.state}</span>
        )}
      </div>

      {/* ZIP */}
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">
          ZIP Code
        </label>
        <input
          type="text"
          name="zip"
          value={address.zip}
          onChange={handleChange}
          maxLength={5}
          className={`w-full p-2 border rounded-md ${
            errors.zip ? 'border-red-500' : 'border-slate-200'
          }`}
          disabled={isConfirmed}
        />
        {errors.zip && (
          <span className="text-xs text-red-500 mt-1">{errors.zip}</span>
        )}
      </div>

      {/* Confirm Button - More prominent styling */}
      <button
        type="button"
        onClick={handleConfirm}
        className="w-full mt-6 py-3 bg-blue-600 text-white rounded-md font-medium text-sm shadow-md"
      >
        [✔] Confirm Address Required
      </button>
      </div>

      {/* Geocoding Error Message */}
      {errors.geocoding && (
        <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md">
          <p className="text-sm text-red-600">{errors.geocoding}</p>
        </div>
      )}
    </div>

      {/* Confirmed Address Box */}
      {isConfirmed && (
        <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-start">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-blue-800">Confirmed Address</h3>
              <div className="mt-1 text-sm text-blue-700">
                {`${address.street_number} ${address.street_name}${
                  address.unit ? ` Unit ${address.unit}` : ''
                }, ${address.city}, ${address.state} ${address.zip}`}
              </div>
              <button
                type="button"
                onClick={() => setIsConfirmed(false)}
                className="mt-2 text-xs text-blue-600 hover:text-blue-700"
              >
                Edit Address
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AddressForm;
